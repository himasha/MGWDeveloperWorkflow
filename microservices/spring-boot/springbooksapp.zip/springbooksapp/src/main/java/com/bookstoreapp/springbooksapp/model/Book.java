package com.bookstoreapp.springbooksapp.model;
public class Book {

    public Book() {

    }

    public Book(Integer id, String title, String author) {
        super();
        this.id = id;
        this.title = title;
        this.author = author;
    }
 
    private Integer id;
    private String title;
    private String author;
    

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    @Override
    public String toString() {
        return "Employee [id=" + id + ", title=" + title + ", author=" + author + "]";
    }
}
