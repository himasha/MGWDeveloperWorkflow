package com.bookstoreapp.springbooksapp.controller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bookstoreapp.springbooksapp.dao.BookDAO;
import com.bookstoreapp.springbooksapp.model.Books;


@RestController
@RequestMapping(path = "/books")
public class BookController 
{
    @Autowired
    private BookDAO bookDao;
    
    @GetMapping(path="/list", produces = "application/json")
    public Books getBookAuthors() 
    {
        return bookDao.getAllBooks();
    }
    
}
