package com.bookstoreapp.springbooksapp.dao;

import org.springframework.stereotype.Repository;

import com.bookstoreapp.springbooksapp.model.Book;
import com.bookstoreapp.springbooksapp.model.Books;


@Repository
public class BookDAO 
{
    private static Books list = new Books();
    
    static 
    {
        list.getBookList().add(new Book(1, "Harry Potter", "J.K.Rowling"));
        list.getBookList().add(new Book(2, "The Lord of the Rings", "J.R.R.Tolkein"));
    }
    
    public Books getAllBooks(){
    	return list;
    }
   
}
